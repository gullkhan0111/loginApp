package com.example.haseeb.loginapp;


public interface OperationListener {
    void add(int result);
    void sub(int result);
}
