package com.example.haseeb.loginapp;

/**
 * Created by haseeb on 2/21/2018.
 */

public interface Searchlistner  {
    void getDataFromDialog(String name);
    void getCityNamefFromDialog(String city);
    void getAgeFromDialog(String UserAge);
}
