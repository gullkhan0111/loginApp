package com.example.haseeb.loginapp;

/**
 * Created by haseeb on 2/22/2018.
 */

public interface DeletetionListener  {
    void DelteFromRealmDatabase(String UserName);
}
