package com.example.haseeb.loginapp;

import io.realm.RealmObject;

/**
 * Created by Rubs on 09-Apr-17.
 */

public class Information extends RealmObject {

    private String username;


    private String password;
    private String cityname;

    String UserAge;

    public String getUserAge() {
        return UserAge;
    }

    public void setUserAge(String userAge) {
        UserAge = userAge;
    }

    @Override
    public String toString() {
        return "Information{" +
                "name='" + username + '\'' +
                ", email='" + password + '\'' +
                ", email='" + cityname + '\'' +
                '}';
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }
}
