package com.example.haseeb.loginapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;


@SuppressLint("ValidFragment")
public class CurrentUser extends Fragment {

    TextView username,password;
    Button logout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_current_user, container, false);
        username = (TextView) view.findViewById(R.id.currentUser_UN);
        password =(TextView)view.findViewById(R.id.passwordTv );
        logout = view.findViewById(R.id.logOut);
     //   city =(TextView)view.findViewById(R.id.city);
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this.getActivity());
        String name = preferences.getString("Name",null);
        String passs = preferences.getString("password",null);
        String cit = preferences.getString("cityname",null);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  SharedPreferences settings = context.getSharedPreferences("PreferencesName", Context.MODE_PRIVATE);
                preferences.edit().clear().commit();
                Intent intent = new Intent(getContext(),LoginActivity.class);
                startActivity(intent);
            }
        });


       if(name.isEmpty()){
          Log.d("name is null",name);
       }else {
           Log.d("name is  Not null",name);
           username.setText(name);
           password.setText(passs);


       }
        return view;

    }


}






