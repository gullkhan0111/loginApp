package com.example.haseeb.loginapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class SearchDialogFragment extends DialogFragment {
    EditText SearchbyUserName, SearchbyCityName, SearchbyAge;
    Button btnSearch;

    Searchlistner searchlistner;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.dialog_signin, container,
                false);
        SearchbyUserName = rootView.findViewById(R.id.SearchUserName);
        SearchbyCityName = rootView.findViewById(R.id.SearchCityName);
        SearchbyAge = rootView.findViewById(R.id.SearchAge);
        btnSearch=rootView.findViewById(R.id.srchButton);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               String userName = SearchbyUserName.getText().toString();
               String cityName = SearchbyCityName.getText().toString();
               String age = SearchbyAge.getText().toString().toString();
               if(cityName.equals("")&& age.equals("")) {
                   searchlistner.getDataFromDialog(userName);
               }else if(age.equals("")&& userName.equals("")) {
                   searchlistner.getCityNamefFromDialog(cityName);

               }else if(userName.equals("")&& cityName.equals("")){
                   searchlistner.getAgeFromDialog(age);
               }

                dismiss();

            }
        });


        return rootView;
    }
    @SuppressLint("LongLogTag")
    public void onAttach(Context context){
        try{
           searchlistner =(Searchlistner)getTargetFragment();
        }catch (ClassCastException ex){
            Log.d("on Attch class casT Exception:", ex.getMessage());
        }
        super.onAttach(context);
    }


}
