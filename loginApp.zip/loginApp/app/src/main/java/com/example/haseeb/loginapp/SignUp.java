package com.example.haseeb.loginapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import io.realm.Realm;
import io.realm.RealmResults;

public class SignUp extends AppCompatActivity {

    EditText EnterUerName, EnterPassword, EnterCityName,age;
    Button btnSignUp;
    Realm realm ;
   public boolean finishActivity=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        EnterUerName = findViewById(R.id.EnterUsername);
        EnterPassword = findViewById(R.id.Enterpassword);
        EnterCityName = findViewById(R.id.cityname);
        age=findViewById(R.id.age);
        btnSignUp = findViewById(R.id.signUp);
        Realm.init(this);
        realm = Realm.getDefaultInstance();
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataBackToLogin();
                Realm realm = Realm.getDefaultInstance();
                Information user = realm.where(Information.class)
                        .equalTo("username", EnterUerName.getText().toString()).findFirst();
                if (user != null) {
                    ToastMessage("User Name Already Exsist");
                } else {
                    btnSignupp();
                }
            }
        });

        }
    private void btnSignupp() {
        if (EnterUerName.getText().toString().isEmpty()) {
            EnterUerName.setError("Required Field");
            return;
        } else {
            EnterUerName.setError(null);
        }

        if (EnterPassword.getText().toString().isEmpty()) {
            EnterPassword.setError("Required Field");
            return;
        } else {
            EnterPassword.setError(null);
        }

        if (EnterCityName.getText().toString().isEmpty()) {
            EnterCityName.setError("Required Field");
            return;
        } else {
            EnterCityName.setError(null);
        }if (age.getText().toString().isEmpty()) {
            EnterCityName.setError("Required Field");
            return;
        } else {
            age.setError(null);
        }
        realm.beginTransaction();
        Information newUser = realm.createObject(Information.class);
        newUser.setUsername(EnterUerName.getText().toString());
        newUser.setPassword(EnterPassword.getText().toString());
        newUser.setCityname(EnterCityName.getText().toString());
        newUser.setUserAge(age.getText().toString());
        realm.commitTransaction();
        finish();

    }
    public void sendDataBackToLogin(){
        Intent intent=new Intent();
        intent.putExtra("name",EnterUerName.getText().toString());
        intent.putExtra("password",EnterPassword.getText().toString());
        setResult(RESULT_OK,intent);
    }

    private void ToastMessage(String meassage) {
        Toast.makeText(this, meassage, Toast.LENGTH_SHORT).show();
    }
}
