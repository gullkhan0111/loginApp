package com.example.haseeb.loginapp;

import android.app.Application;

import io.realm.Realm;

/**
 * Created by haseeb on 2/20/2018.
 */

public class AppApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
    }
}
