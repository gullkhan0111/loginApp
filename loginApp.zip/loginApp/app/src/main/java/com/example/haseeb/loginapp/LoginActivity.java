package com.example.haseeb.loginapp;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import io.realm.Realm;

public class LoginActivity extends AppCompatActivity {
    public EditText username, password;
    Button logIn, Register;
    String name;
    String key;

    CheckBox RemembarMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        logIn = findViewById(R.id.logIn);
        RemembarMe = findViewById(R.id.saveLoginCheckBox);
        Register = findViewById(R.id.Register);


        logIn.setOnClickListener(new View.OnClickListener() {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
            SharedPreferences.Editor editor = preferences.edit();

            @Override
            public void onClick(View view) {
                if (username.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
                    ToastMessage("Enter Username/password");
                } else {
                    if (RemembarMe.isChecked()) {
                        ToastMessage("cheakBoc is clcikd");
                        editor.putBoolean("save", true);
                        editor.apply();
                        editor.commit();

                    }

                    name = username.getText().toString();
                    key = password.getText().toString();
                    checkUser(name, key);
                    editor.putString("Name", name);
                    editor.putString("password", key);
                    editor.apply();
                    editor.commit();

                }

            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, SignUp.class);
                startActivityForResult(i, 1);
            }
        });

    }

    protected void onStart() {
        super.onStart();
        SharedPreferences prefes = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        Boolean yourLocked = prefes.getBoolean("save", false);
        System.out.println("boolean value is " + yourLocked);
        if (yourLocked == true) {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivityForResult(intent,1);
        }

    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if (resultCode == RESULT_OK && requestCode == 1) {
            String message = data.getStringExtra("name");
            username.setText(message);
            String pass = data.getStringExtra("password");
            username.setText(message);
            password.setText(pass);
        }
    }

    private void checkUser(String name, String pass) {

        Realm realm = Realm.getDefaultInstance();

        Information user = realm.where(Information.class)
                .equalTo("username", name)
                .and()
                .equalTo("password", pass)
                .findFirst();

        if (user == null) {
            Toast.makeText(this, "Wrong Credentials", Toast.LENGTH_SHORT).show();
        } else {



            Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }


    }

    private void ToastMessage(String message) {
        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
    }


}