package com.example.haseeb.loginapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import io.realm.Realm;
import io.realm.RealmResults;

public class AlluserTab extends Fragment implements Searchlistner {


    private RecyclerView recyclerView;
    Button searchbutton, showAllUser;
    EditText textValue;
    FloatingActionButton floatingActionButton;

    String name;


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dialog_box, container, false);
    }


    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recylerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        floatingActionButton = view.findViewById(R.id.floatingActionButton);
        textValue = view.findViewById(R.id.srhUser);
        showAllUser = view.findViewById(R.id.showAllUser);
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this.getActivity());
        Realm.init(getContext());

        final Realm realm = Realm.getDefaultInstance();
        RealmResults<Information> allUsers = realm.where(Information.class).findAll();
        recyclerView.setAdapter(new UserListAdapter(allUsers));

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DialogFragment searchDialog = new SearchDialogFragment();
                searchDialog.show(getFragmentManager(), "fragment_dialog");
                searchDialog.setTargetFragment(AlluserTab.this, 1);


            }

        });
        showAllUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Realm realm = Realm.getDefaultInstance();
                RealmResults<Information> allUsers = realm.where(Information.class).findAll();
                recyclerView.setAdapter(new UserListAdapter(allUsers));
            }
        });

    }

    @Override
    public void getDataFromDialog(String name) {
        System.out.println("sent name is " + name);
        SearhingInDatabaseByUserName(name);


    }

    @Override
    public void getCityNamefFromDialog(String city) {
        SearhingInDatabaseByUserCityName(city);
    }

    @Override
    public void getAgeFromDialog(String UserAge) {
        SearhingInDatabaseByUserAge(UserAge);
    }

    private void SearhingInDatabaseByUserAge(String agg) {

        final Realm realm = Realm.getDefaultInstance();
        RealmResults<Information> user = realm.where(Information.class)
                .equalTo("UserAge", agg.toString())
                .findAll();
        if (user.isEmpty()) {
            Toast.makeText(getActivity(), "User Not Found", Toast.LENGTH_SHORT).show();
        } else {
            recyclerView.setAdapter(new UserListAdapter(user));
        }

    }

    private void SearhingInDatabaseByUserCityName(String cit) {
        final Realm realm = Realm.getDefaultInstance();
        RealmResults<Information> user = realm.where(Information.class)
                .equalTo("cityname", cit.toString())
                .findAll();
        if (user.isEmpty()) {
            Toast.makeText(getActivity(), "User Not Found", Toast.LENGTH_SHORT).show();
        } else {
            recyclerView.setAdapter(new UserListAdapter(user));
        }


    }

    private void SearhingInDatabaseByUserName(String name) {
        final Realm realm = Realm.getDefaultInstance();
        RealmResults<Information> user = realm.where(Information.class)
                .equalTo("username", name.toString())
                .findAll();
        if (user.isEmpty()) {
            Toast.makeText(getActivity(), "User Not Found", Toast.LENGTH_SHORT).show();
        } else {
            recyclerView.setAdapter(new UserListAdapter(user));
        }

    }




}


