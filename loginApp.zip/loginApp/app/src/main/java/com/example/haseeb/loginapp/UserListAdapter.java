package com.example.haseeb.loginapp;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import io.realm.Realm;
import io.realm.RealmResults;


class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.UserViewHolder>  {
    AlluserTab alluserTab= new AlluserTab();


    RealmResults<Information> data;

    public UserListAdapter(RealmResults<Information> data) {
        this.data = data;
    }



    @Override
    public UserListAdapter.UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.userlist, parent, false);
        return new UserViewHolder(view);

    }

    @Override
    public void onBindViewHolder(UserListAdapter.UserViewHolder holder, int position) {
        holder.userlst.setText(data.get(position).getUsername());


    }

    @Override
    public int getItemCount() {
        return data.size();

    }

    public void deleteStudentByUserName(String userName) {
        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        Information result = realm.where(Information.class).equalTo("username",userName).findFirst();
        result.deleteFromRealm();
        notifyDataSetChanged();
        realm.commitTransaction();


    }


    public class UserViewHolder extends RecyclerView.ViewHolder {
        TextView userlst;
        ImageView AllUserIcon,deleteIcon;

        public UserViewHolder(View itemView) {

            super(itemView);
            userlst = itemView.findViewById(R.id.UserName);
         //   AllUserIcon = itemView.findViewById(R.id.AllUser_imgIcon);
            deleteIcon=itemView.findViewById(R.id.deleteButton);

           deleteIcon.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {

                   int  pos =  getLayoutPosition();
                  // data.get(getAdapterPosition()).getUsername()
                   deleteStudentByUserName(data.get(getAdapterPosition()).getUsername());

               }
           });

        }

    }


}
